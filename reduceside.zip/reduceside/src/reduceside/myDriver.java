package reduceside;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myDriver {
public static void main(String args[]) throws IOException, ClassNotFoundException, InterruptedException{
	Configuration conf=new Configuration();
	Job j=new Job(conf,"Reduce Join");
	j.setJarByClass(myDriver.class);
	j.setMapperClass(myMapper.class);
	j.setMapperClass(myMapper1.class);
	j.setReducerClass(myReducer.class);
	j.setNumReduceTasks(1);
	j.setMapOutputKeyClass(Text.class);
	j.setMapOutputValueClass(Text.class);
	MultipleInputs.addInputPath(j, new Path(args[0]), TextInputFormat.class, myMapper.class);
	MultipleInputs.addInputPath(j, new Path(args[1]), TextInputFormat.class, myMapper1.class); 
	
	FileOutputFormat.setOutputPath(j, new Path(args[2]));
	
	System.exit(j.waitForCompletion(true)?0:1);

}
}
