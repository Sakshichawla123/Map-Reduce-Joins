package customer;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class joinReducer extends Reducer<Object,Text,Text,Text>{
public void reduce(Text key, Iterable<Text> values, Context c) throws IOException, InterruptedException{
	String prof="";
	double max=0.0;
	int count=0;
	int total=0;
	for(Text t : values){
		String val[]=t.toString().split(":");
		if(val[0].equals("trans")){
			total+=Float.parseFloat(val[1]);
		}
		else
		{
			prof=val[1];
		}
		String s[]=key.toString().split(":");
		c.write(new Text(s[1]), new Text(" "+prof+" "+total));
			}
}
}
