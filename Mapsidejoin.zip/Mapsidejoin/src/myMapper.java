import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable,Text,Text,Text> {
HashMap<String,String>hm=new HashMap<>();
public void setup(Context c) throws IOException{
	Path[] allFiles=DistributedCache.getLocalCacheFiles(c.getConfiguration());
	for(Path eachFile:allFiles){
		if(eachFile.getName().equals("dept.txt"));
		
		{
			FileReader fr=new FileReader(eachFile.toString());
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null){
				String eachval[]=line.split(",");
				String deptid = eachval[0];
				String deptname=eachval[1];
				hm.put(deptid, deptname);
				line=br.readLine();
			}
			br.close();
			if(hm.isEmpty())
			{
				throw new IOException("unable to load file");
			}
		}
	}
}
	public void Map(Text inpk, Text inpv, Context c) throws IOException, InterruptedException{
		String line=inpv.toString();
		String eachval[]=line.split(",");
		String deptid=eachval[2];
		String empname=eachval[1];
		String deptname=hm.get(deptid);
		Text outk=new Text("Dept ID :"+deptid+"Dept name :"+deptname);
		Text outv=new Text(empname);
		c.write(outk, outv);
	}
}

